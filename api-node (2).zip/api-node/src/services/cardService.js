const bcrypt = require('bcrypt');
const cardRepository = require('../repositories/cardRepository');
const { v4: UUIDV4 } = require('uuid');
const jwt = require('jsonwebtoken');

const SECRET_KEY = 'chave_secreta'

class CardService{
    async getAll(){
        return await cardRepository.findAll();
    }

    async getByUserName(username){
        return cardRepository.findByUserName(username);
    }

    async register(ataque, defesa, nivel, custo, namecard, descricao, urlImagem){
        if(username === ""){
            throw new Error('Preencha o username!');
        }

        if(password === ""){
            throw new Error('Preencha a senha!');
        }

        const user = await this.getByUserName(username);

        if(user){
            throw new Error('Username indisponivel')
        }

        const hashedPassword = await bcrypt.hash(password, 10);
        const id = UUIDV4();
        return await cardRepository.createUser({
            id,
            username,
            password: hashedPassword
        });
    }

    async login(username, password){
        const user = await this.getByUserName(username);
        if(!user){
            throw new Error('Usuário ou Senha Inválidos');
        }

        const inValidPassword = await bcrypt.compare(password, user.password);
        if(!inValidPassword){
            throw new Error('Usuário ou Senha Inválidos');
        }
        const token = jwt.sign({id: user.id}, SECRET_KEY, {expiresIn: '1h'})
        return token;

    }

    async delete(username){
        const user = await this.getByUserName(username);
        if(!user){
            throw new Error('Usuário inválido');
        }

        cardRepository.delete(user.id);
    }
}

module.exports = new CardService();