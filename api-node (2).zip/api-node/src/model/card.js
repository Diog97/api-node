const { Sequelize, DataTypes } = require('sequelize')
const sequelize = require('../config/database')

const Card = sequelize.define('Users',
    {
        id:{
            type: DataTypes.UUIDV4,
            primaryKey: true
        },
        ataque:{
            type: DataTypes.INTEGER,
            allowNull: false
        },
        defesa:{
            type: DataTypes.INTEGER,
            allowNull: false
        },
        nivel:{
            type: DataTypes.INTEGER,
            allowNull: false
        },
        custo:{
            type: DataTypes.INTEGER,
            allowNull: false
        },
        namecard:{
            type: DataTypes.STRING,
            allowNull: false
        },
        descricao:{
            type: DataTypes.STRING,
            allowNull: false
        },
        urlImagem: {
            type: DataTypes.STRING,
            allowNull: false
        }
    }
)

module.exports = Card;