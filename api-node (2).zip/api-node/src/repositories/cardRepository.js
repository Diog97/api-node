const { where } = require('sequelize');
const Card = require('../model/card');

class CardRepository {
    async createUser(card){
        return await Card.create(card);
    }

    async findAll(){
        return await Card.findAll();
    }

    async findByUserName(namecard){
        return await Card.findOne({ where: {namecard}})
    }

    async delete(id){
        await Card.destroy({where: {id}})
    }
}

module.exports = new CardRepository();